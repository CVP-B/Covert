name		= "Covert";								// Name of your mod
picture 	= "\Covert\mod\picture.paa"; 		// Picture displayed from the expansions menu. Optimal size is 2048x1024
logoSmall	= "\Covert\mod\logo_small.paa";	// Display next to the item added by the mod
logo		= "\Covert\mod\logo.paa";			// Logo displayed in the main menu
logoOver	= "\Covert\mod\logoOver.paa";		// When the mouse is over, in the main menu
action		= "https://CovertParadise.com/Covert/";			// Website URL, that can accessed from the expansions menu

dlcColor[] =
{
	0.23,
	0.39,
	0.30,
	1
};

hideName	= 0;	// Hide the extension name
hidePicture	= 0;	// Hide the extension menu